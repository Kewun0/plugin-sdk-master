/*
Plugin-SDK (Grand Theft Auto 3) source file
Authors: GTA Community. See more here
https://github.com/DK22Pac/plugin-sdk
Do not delete this comment block. Respect others' work!
*/
#include "CZone.h"

const wchar_t* CZone::GetTranslatedName()
{
    return ((const wchar_t *(__thiscall*)(CZone *))0x4B5DD0)(this);
}
