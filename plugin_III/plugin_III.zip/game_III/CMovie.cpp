/*
    Plugin-SDK (Grand Theft Auto Vice City) source file
    Authors: GTA Community. See more here
    https://github.com/DK22Pac/plugin-sdk
    Do not delete this comment block. Respect others' work!
*/
#include "CMovie.h"

// Converted from thiscall void CMovie::CMovie(void) 0x588480 
CMovie::CMovie() {
    plugin::CallMethod<0x588480, CMovie *>(this);
}
