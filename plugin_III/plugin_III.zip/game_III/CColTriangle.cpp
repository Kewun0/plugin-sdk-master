/*
Plugin-SDK (Grand Theft Auto 3) source file
Authors: GTA Community. See more here
https://github.com/DK22Pac/plugin-sdk
Do not delete this comment block. Respect others' work!
*/
#include "CColTriangle.h"

// Converted from thiscall void CColTriangle::Set(CompressedVector const*,int,int,int,uchar,uchar) 0x411E70
void CColTriangle::Set(CompressedVector const* arg0, int arg1, int arg2, int arg3, unsigned char arg4, unsigned char arg5) {
    plugin::CallMethod<0x411E70, CColTriangle *, CompressedVector const*, int, int, int, unsigned char, unsigned char>(this, arg0, arg1, arg2, arg3, arg4, arg5);
}