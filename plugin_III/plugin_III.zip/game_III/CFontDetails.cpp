/*
Plugin-SDK (Grand Theft Auto 3) header file
Authors: GTA Community. See more here
https://github.com/DK22Pac/plugin-sdk
Do not delete this comment block. Respect others' work!
*/
#include "CFontDetails.h"

// Converted from thiscall void CFontDetails::~CFontDetails() 0x501F10
CFontDetails::~CFontDetails() {
    plugin::CallMethod<0x501F10, CFontDetails *>(this);
}
