/*
Plugin-SDK (Grand Theft Auto 3) header file
Authors: GTA Community. See more here
https://github.com/DK22Pac/plugin-sdk
Do not delete this comment block. Respect others' work!
*/
#include "CPlaceName.h"

// Converted from thiscall void CPlaceName::CPlaceName(void) 0x4AD4B0 
CPlaceName::CPlaceName() {
    plugin::CallMethod<0x4AD4B0, CPlaceName *>(this);
}

// Converted from thiscall void CPlaceName::Display(void) 0x4AD5B0 
void CPlaceName::Display() {
    plugin::CallMethod<0x4AD5B0, CPlaceName *>(this);
}

// Converted from thiscall void CPlaceName::Init(void) 0x4AD4C0 
void CPlaceName::Init() {
    plugin::CallMethod<0x4AD4C0, CPlaceName *>(this);
}

// Converted from thiscall void CPlaceName::Process(void) 0x4AD4E0 
void CPlaceName::Process() {
    plugin::CallMethod<0x4AD4E0, CPlaceName *>(this);
}
